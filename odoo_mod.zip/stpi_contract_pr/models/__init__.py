# -*- coding: utf-8 -*-

from . import hr_payroll
from . import hr_employee_contracts
from . import res_city_inherit