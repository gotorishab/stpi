# -*- coding: utf-8 -*-

from . import advertisement_recruitment
from . import hr_job_inherit
# from . import hr_applicant