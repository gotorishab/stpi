==================
HR Applicant
==================

* Extend features of recruitment process and Manage Training

* This module helps you to keep employee information.
	
* Have subsections in Applicant and Employee forms to have several informations like Medical details, Relatives, Previous Occupations etc. 

* Informations which will filled for Applicant will be added automatically in Employee when applicant will converted into Employee. 

* This application allows you to keep description for details of Applicant and Employee like Attachment of Subsections,Medical

  Details,Previous Occupation,Education Details,Relatives,Languages,Pervious Travel and Profile Report
 
Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

