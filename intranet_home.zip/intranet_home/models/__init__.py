# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from . import useful_links
from . import employe_birthday_anniversary
from . import masters
from . import slider
from . import ir_module_module
from . import blog_confuguration
from . import website
from . import res_user
from . import blog_confuguration
from . import blog_post_categories
from . import event
from . import user_management
from . import story_management
from . import discussion_forum
